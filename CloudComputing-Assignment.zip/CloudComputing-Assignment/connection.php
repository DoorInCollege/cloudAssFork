<?php
define('DB_HOST', 'gradshopdb.ccogzbczpxpn.us-east-1.rds.amazonaws.com'); // DB endpoint
define('DB_USER', 'GradShopAdmin'); // master user
define('DB_PASS', 'gs123456'); // master pw
define('DB_NAME', 'gradshopDB'); // db name 
?>