<?php
include "connection.php"; include "adminheader.php"; ?>

<h2>Admin Dashboard</h2>

<h3>Delete Product</h3>

<style>
    .admin-content {
            max-width: 1100px;}
</style>

<?php
$con = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    // Optional: fetch image name to delete the image file as well
    $imageSql = "SELECT image FROM products WHERE id = ?";
    $stmt = $con->prepare($imageSql);
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $stmt->bind_result($image);
    $stmt->fetch();
    $stmt->close();

    // Delete from database
    $deleteSql = "DELETE FROM products WHERE id = ?";
    $stmt = $con->prepare($deleteSql);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        // Optional: delete image file
        if ($image && file_exists("images/" . $image)) {
            unlink("images/" . $image);
        }

        // Redirect or show message
        header("Location: adminpage.php");
        exit();
    } else {
        echo "<div class='notification error'>Failed to delete product.</div>";
    }

    $stmt->close();
} else {
    echo "<div style='color: red; font-size: 18px;'>Error: Product ID is missing.</div>";
    echo "<p><a href='adminpage.php'>Go back to Dashboard</a></p>";
    exit();
}

$con->close();
?>

<?php include "footer.php"; ?>
</body>
</html>