<?php
session_start();
include 'connection.php';

$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

function load_cart() {
    if (isset($_COOKIE['my_cart'])) {
        return json_decode($_COOKIE['my_cart'], true);
    }
    return [];
}

function clear_cart() {
    setcookie('my_cart', '', time() - 3600, "/");
}

function sanitize_input($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

function format_payment_method($payment_method) {
    return str_replace('_', ' ', ucfirst($payment_method));
}

function validate_payment_data($data, &$errors) {
    if (empty($data['payment_method'])) {
        $errors['payment_method'] = "Please select a payment method.";
    }

    if ($data['payment_method'] === 'credit_card' || $data['payment_method'] === 'debit_card') {
        $card_number_field = ($data['payment_method'] === 'credit_card') ? 'cc_number' : 'dc_number';
        $card_expiry_field = ($data['payment_method'] === 'credit_card') ? 'cc_expiry' : 'dc_expiry';
        $card_cvv_field = ($data['payment_method'] === 'credit_card') ? 'cc_cvv' : 'dc_cvv';
    
        if (empty($data[$card_number_field])) {
            $errors[$card_number_field] = "Card Number is required.";
        } elseif (!preg_match("/^\d{16}$/", $data[$card_number_field])) {
            $errors[$card_number_field] = "Invalid Card Number format.";
        }
    
        if (empty($data[$card_expiry_field])) {
            $errors[$card_expiry_field] = "Expiry Date is required.";
        } elseif (!preg_match("/^(0[1-9]|1[0-2])\/(\d{2})$/", $data[$card_expiry_field])) {
            $errors[$card_expiry_field] = "Invalid Expiry Date format (MM/YY).";
        } else {
            $expiry_parts = explode('/', $data[$card_expiry_field]);
            $expiry_month = intval($expiry_parts[0]);
            $expiry_year = 2000 + intval($expiry_parts[1]);
            $current_month = intval(date('m'));
            $current_year = intval(date('Y'));
    
            if ($expiry_year < $current_year || ($expiry_year == $current_year && $expiry_month < $current_month)) {
                $errors[$card_expiry_field] = "Card has expired.";
            }
        }
    
        if (empty($data[$card_cvv_field])) {
            $errors[$card_cvv_field] = "CVV is required.";
        } elseif (!preg_match("/^\d{3}$/", $data[$card_cvv_field])) {
            $errors[$card_cvv_field] = "Invalid CVV format.";
        }
    } elseif ($data['payment_method'] === 'tng') {
        if (empty($data['tng_number'])) {
            $errors['tng_number'] = "TNG Number is required.";
        } elseif (!preg_match("/^01\d{8,9}$/", $data['tng_number'])) {
            $errors['tng_number'] = "Invalid TNG Number format.";
        }
    }
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize all input data
    $post_data = array_map('sanitize_input', $_POST);

    // Validate the data
    $errors = [];
    validate_payment_data($post_data, $errors);

    // If there are validation errors, redirect back to payment.php
    if (!empty($errors)) {
        // IMPORTANT: Store checkout data in the expected format for payment.php
        $_SESSION['payment_errors'] = $errors;
        $_SESSION['checkout_data'] = [
            'customer_name' => $post_data['customer_name'],
            'customer_email' => $post_data['customer_email'],
            'shipping_address_street' => $post_data['shipping_address_street'],
            'shipping_address_city' => $post_data['shipping_address_city'],
            'shipping_address_state' => $post_data['shipping_address_state'],
            'shipping_address_postal_code' => $post_data['shipping_address_postal_code'],
            'customer_phone' => $post_data['customer_phone'],
            'total_amount' => $post_data['total_amount'],
            'delivery_fee' => $post_data['delivery_fee']
        ];
        
        header("Location: payment.php");
        exit();
    }

    // If validation passes, proceed with processing the order
    $customer_name = $post_data['customer_name'];
    $customer_email = $post_data['customer_email'];
    $shipping_address_street = $post_data['shipping_address_street'];
    $shipping_address_city = $post_data['shipping_address_city'];
    $shipping_address_state = $post_data['shipping_address_state'];
    $shipping_address_postal_code = $post_data['shipping_address_postal_code'];
    $customer_phone = $post_data['customer_phone'];
    $total_amount = floatval($post_data['total_amount']);
    $delivery_fee = floatval($post_data['delivery_fee']);
    $payment_method = $post_data['payment_method'];

    $cc_last_digits = '';
    $tng_masked_number = '';

    if ($payment_method === 'credit_card' || $payment_method === 'debit_card') {
        $card_number_field = ($payment_method === 'credit_card') ? 'cc_number' : 'dc_number';
        $cc_last_digits = substr($post_data[$card_number_field], -4);
    } elseif ($payment_method === 'tng') {
        $tng_masked_number = "01x-xxx-" . substr($post_data['tng_number'], -4);
    }

    $cart = load_cart();

    mysqli_begin_transaction($conn);

    try {
        $order_query = "INSERT INTO orders (total_amount, delivery_fee, customer_name, customer_email, shipping_address_street, shipping_address_city, shipping_address_state, shipping_address_postal_code, customer_phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $order_stmt = mysqli_prepare($conn, $order_query);
        mysqli_stmt_bind_param($order_stmt, "ddsssssss", $total_amount, $delivery_fee, $customer_name, $customer_email, $shipping_address_street, $shipping_address_city, $shipping_address_state, $shipping_address_postal_code, $customer_phone);
        mysqli_stmt_execute($order_stmt);
        $order_id = mysqli_insert_id($conn);

        $payment_query = "INSERT INTO payments (order_id, payment_method, cc_last_digits, tng_masked_number) VALUES (?, ?, ?, ?)";
        $payment_stmt = mysqli_prepare($conn, $payment_query);
        mysqli_stmt_bind_param($payment_stmt, "isss", $order_id, $payment_method, $cc_last_digits, $tng_masked_number);
        mysqli_stmt_execute($payment_stmt);

        foreach ($cart as $item_key => $item_data) {
            $parts = explode('-', $item_key);
            $product_id = $parts[0];
            $size = $parts[1];
            $quantity = $item_data['quantity'];

            $product_query = "SELECT price FROM products WHERE id = ?";
            $product_stmt = mysqli_prepare($conn, $product_query);
            mysqli_stmt_bind_param($product_stmt, "i", $product_id);
            mysqli_stmt_execute($product_stmt);
            $product_result = mysqli_stmt_get_result($product_stmt);
            $product_details = mysqli_fetch_assoc($product_result);
            $price = $product_details['price'];

            $item_query = "INSERT INTO order_items (order_id, product_id, quantity, size, price) VALUES (?, ?, ?, ?, ?)";
            $item_stmt = mysqli_prepare($conn, $item_query);
            mysqli_stmt_bind_param($item_stmt, "iiisd", $order_id, $product_id, $quantity, $size, $price);
            mysqli_stmt_execute($item_stmt);

            $update_query = "UPDATE products SET stock = stock - ? WHERE id = ?";
            $update_stmt = mysqli_prepare($conn, $update_query);
            mysqli_stmt_bind_param($update_stmt, "ii", $quantity, $product_id);
            mysqli_stmt_execute($update_stmt);
        }

        mysqli_commit($conn);

        clear_cart();

        $formatted_payment_method = format_payment_method($payment_method);
        $payment_info = "Payment Method: " . $formatted_payment_method;
        if ($payment_method === 'credit_card' || $payment_method === 'debit_card') {
            $card_number_field = ($payment_method === 'credit_card') ? 'cc_number' : 'dc_number';
            $last_digits = substr($post_data[$card_number_field], -4);
            $payment_info .= ", Card ending in: " . $last_digits;
        } elseif ($payment_method === 'tng') {
            $tng_masked_number = "01x-xxx-" . substr($post_data['tng_number'], -4);
            $payment_info .= ", TNG Number ending in: " . substr($tng_masked_number, -4);
        }

        header("Location: order_confirmation.php?order_id=" . $order_id . "&payment_info=" . urlencode($payment_info) . "&delivery_fee=" . urlencode($delivery_fee));
        exit();

    } catch (Exception $e) {
        mysqli_rollback($conn);
        // Log the error for debugging
        error_log("Database error processing order: " . $e->getMessage(), 0);
        
        // Store error message and checkout data for redisplay
        $_SESSION['payment_errors'] = ['system' => "Error processing order. Please try again."];
        $_SESSION['checkout_data'] = [
            'customer_name' => $post_data['customer_name'],
            'customer_email' => $post_data['customer_email'],
            'shipping_address_street' => $post_data['shipping_address_street'],
            'shipping_address_city' => $post_data['shipping_address_city'],
            'shipping_address_state' => $post_data['shipping_address_state'],
            'shipping_address_postal_code' => $post_data['shipping_address_postal_code'],
            'customer_phone' => $post_data['customer_phone'],
            'total_amount' => $post_data['total_amount'],
            'delivery_fee' => $post_data['delivery_fee']
        ];
        
        header("Location: payment.php");
        exit();
    }

} else {
    // Redirect to checkout if accessed directly
    header("Location: checkout.php");
    exit();
}
?>