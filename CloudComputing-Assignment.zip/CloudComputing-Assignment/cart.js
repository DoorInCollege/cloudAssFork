function showToast(message, isError = false, showCartButton = false) {
    let toastContainer = document.querySelector('.toast-container');
    if (!toastContainer) {
        toastContainer = document.createElement('div');
        toastContainer.className = 'toast-container';
        document.body.appendChild(toastContainer);
    }

    const toast = document.createElement('div');
    toast.className = isError ? 'toast error' : 'toast';

    const icon = document.createElement('span');
    icon.className = 'toast-icon';
    icon.innerHTML = isError ? '❌' : '✅';

    const msgElement = document.createElement('span');
    msgElement.className = 'toast-message';
    msgElement.textContent = message;

    toast.appendChild(icon);
    toast.appendChild(msgElement);

    if (showCartButton) {
        const cartButton = document.createElement('button');
        cartButton.textContent = 'View Cart';
        cartButton.classList.add('toast-cart-button');
        cartButton.addEventListener('click', () => {
            window.location.href = 'shoppingcart.php';
        });
        toast.appendChild(cartButton);
    }

    toastContainer.appendChild(toast);

    setTimeout(() => {
        toast.remove();
    }, 5000);
}

function updatePrice(productName) {
    const sizeSelect = document.getElementById('size_' + productName);
    const selectedOption = sizeSelect.options[sizeSelect.selectedIndex];
    const selectedPrice = selectedOption.getAttribute('data-price');

    if (selectedPrice) {
        document.getElementById('price_' + productName).textContent = selectedPrice;
    } else {
        let defaultPrice = null;
        for (let i = 0; i < sizeSelect.options.length; i++) {
            const price = sizeSelect.options[i].getAttribute('data-price');
            if (price) {
                defaultPrice = price;
                break;
            }
        }
        if (defaultPrice) {
            document.getElementById('price_' + productName).textContent = defaultPrice;
        }
    }
}

function handleAddToCart(productName) {
    const sizeSelect = document.getElementById('size_' + productName);

    if (!sizeSelect) {
        showToast('Error: Product element not found', true);
        return;
    }

    const selectedOption = sizeSelect.options[sizeSelect.selectedIndex];
    const selectedSize = selectedOption.value;

    if (!selectedSize) {
        showToast('Please select a size', true);
        return;
    }

    const selectedProductId = selectedOption.getAttribute('data-product-id');
    const selectedPrice = selectedOption.getAttribute('data-price');

    if (selectedProductId) {
        fetch('addtocart.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: 'product_id=' + encodeURIComponent(selectedProductId) +
                  '&quantity=1&size=' + encodeURIComponent(selectedSize)
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                const productDisplayName = productName.replace(/_/g, ' ');
                showToast(`${productDisplayName} (${selectedSize}) added to cart`, false, true);
            } else {
                showToast('Error: ' + data.message, true);
            }
        })
        .catch(error => {
            console.error('Error:', error);
            showToast('An error occurred while adding to cart', true);
        });
    } else {
        showToast('Product information not available', true);
    }
}

function removeItem(itemKey) {
    fetch('remove_from_cart.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/x-www-form-urlencoded'
        },
        body: 'item_key=' + encodeURIComponent(itemKey)
    })
    .then(response => response.json())
    .then(data => {
        if (data.status === 'success') {
            showToast('Item removed from cart');
            setTimeout(() => {
                window.location.reload();
            }, 1000);
        } else {
            showToast('Error: ' + data.message, true);
        }
    })
    .catch(error => {
        console.error('Error:', error);
        showToast('An error occurred while removing the item', true);
    });
}

function updateCartTotal() {
    let cartTotal = 0;
    document.querySelectorAll('.cart-item').forEach(item => {
        const itemKey = item.getAttribute('data-item-key');
        const quantity = parseInt(document.getElementById(`quantity_${itemKey}`).value, 10);
        const priceElement = item.querySelector('.price');
        const priceText = priceElement.textContent.replace('RM', ''); // Remove "RM"
        const price = parseFloat(priceText);
        cartTotal += quantity * price;
    });
    const cartTotalElement = document.querySelector('.cart-summary .cart-total');
    if (cartTotalElement) {
        cartTotalElement.textContent = 'RM' + cartTotal.toFixed(2);
    }
}

document.addEventListener('DOMContentLoaded', function() {
    const updateQuantityButtons = document.querySelectorAll('.update-quantity-btn');

    updateQuantityButtons.forEach(button => {
        button.addEventListener('click', function() {
            const itemKey = this.getAttribute('data-item-key');
            const quantityInput = document.getElementById(`quantity_${itemKey}`);
            const newQuantity = parseInt(quantityInput.value, 10);

            if (isNaN(newQuantity) || newQuantity < 1) {
                showToast('Please enter a valid quantity', true);
                quantityInput.value = document.querySelector(`.cart-item[data-item-key="${itemKey}"] input[type="number"]`).value;
                return;
            }

            fetch('shoppingcart.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: `update_quantity=true&item_key=${encodeURIComponent(itemKey)}&quantity=${encodeURIComponent(newQuantity)}`,
            })
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success') {
                    showToast('Quantity updated');
                    const itemSubtotalValueElement = document.querySelector(`.cart-item[data-item-key="${itemKey}"] .subtotal-value`);
                    if (itemSubtotalValueElement && data.new_subtotal) {
                        itemSubtotalValueElement.textContent = data.new_subtotal;
                    }
                    updateCartTotal();
                } else {
                    showToast('Error updating quantity: ' + data.message, true);
                    quantityInput.value = document.querySelector(`.cart-item[data-item-key="${itemKey}"] input[type="number"]`).value;
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showToast('An error occurred while updating quantity', true);
                quantityInput.value = document.querySelector(`.cart-item[data-item-key="${itemKey}"] input[type="number"]`).value;
            });
        });
    });

    updateCartTotal();
});