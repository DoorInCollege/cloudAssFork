<?php include "adminheader.php"; ?>

<h2>Admin Dashboard</h2>

<h3>Product List</h3>

<?php
include "connection.php";

$con = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

$sql = "SELECT id, name, shortDesc, description, image, size, stock, price FROM products";
$result = $con->query($sql);

if ($result->num_rows > 0) {
    echo "<table>";
    echo "<thead><tr><th>ID</th><th>Name</th><th>Short Description</th><th>Image</th><th>Size</th><th>Stock</th><th>Price</th><th>Actions</th></tr></thead>";
    echo "<tbody>";
    while ($row = $result->fetch_assoc()) {
        echo "<tr>";
        echo "<td>" . $row["id"] . "</td>";
        echo "<td>" . $row["name"] . "</td>";
        echo "<td>" . $row["shortDesc"] . "</td>";
        echo "<td>";
        if (!empty($row["image"])) {
            echo "<img src='" ."images/". $row["image"] . "' alt='" . $row["name"] . "' style='height: 150px; display:block; margin:auto; '>";
        } else {
            echo "No image";
        }
        echo "</td>";
        echo "<td>" . $row["size"] . "</td>";
        echo "<td>" . $row["stock"] . "</td>";
        echo "<td>" . $row["price"] . "</td>";
        echo "<td>";
        echo "<a href='edit_product.php?id=" . $row["id"] . "'>Edit</a> | ";
        echo "<a href='delete_product.php?id=" . $row["id"] . "' onclick='return confirm(\"Are you sure you want to delete this product?\")'>Delete</a>";
        echo "</td>";
        echo "</tr>";
    }
    echo "</tbody>";
    echo "</table>";
} else {
    echo "<p>No products found in the database.</p>";
}

$con->close();
?>

</div> <?php include "footer.php"; ?>
</body>
</html>