# CloudComputing-Assignment
Y2S3 

staff1 
pw:123

staff2 
pw:123
