<?php 
include "adminheader.php"; 
include "connection.php";

$con = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get updated values from the form
    $name = $_POST['name'];
    $shortDesc = $_POST['shortDesc'];
    $size = $_POST['size'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];   
    $image = $_FILES['image'];

    $sql = "SELECT COUNT(*) FROM products WHERE name = ? AND size = ?";
    $checkStmt = $con->prepare($sql); $checkStmt->bind_param("ss", $name, $size); $checkStmt->execute();
    $checkStmt->bind_result($count); $checkStmt->fetch(); $checkStmt->close();

    if ($count > 0) {
        echo "<div class='notification error'>Product with the same name and size already exists!</div>";
    } else {
        $imageName = basename($_FILES['image']['name']);
        $targetDir = "images/";
        $targetFile = $targetDir . $imageName;

    if (move_uploaded_file($_FILES['image']['tmp_name'], $targetFile)) {
        // Insert new product
        $insertSql = "INSERT INTO products (name, shortDesc, size, price, stock, image) VALUES (?, ?, ?, ?, ?, ?)";
        $insertStmt = $con->prepare($insertSql);
        $insertStmt->bind_param("sssdis", $name, $shortDesc, $size, $price, $stock, $imageName);
        
        if ($insertStmt->execute()) {
            echo "<div class='notification success'>New product added successfully!</div>";
            echo "<p><a href='adminpage.php'>Go back to Dashboard</a></p>";
            exit();
        } else {
            echo "<div class='notification error'>Failed to add product.</div>";
        }
        $insertStmt->close();
    }
}
}

?>

<h2>Admin Dashboard</h2>

<h3>Add New Product</h3>

<style>
    .admin-content {
            max-width: 1100px;}
</style>

<script>
document.querySelector('input[name="image"]').addEventListener('change', function(event) {
    const file = event.target.files[0];
    if (file) {
        const img = document.querySelector('img');
        img.src = URL.createObjectURL(file);
    }
});
</script>

<form action="add_product.php" method="POST" enctype="multipart/form-data">
    <div style="display: flex; justify-content: center; margin-bottom: 20px; gap: 30px;">

        <!-- Left side: Image placeholder -->
        <div>
        <label style="font-size: 23px;">Image: </label>
        <input type="file" style="font-size: 23px;" name="image" accept="image/*" required><br><br>
            <img src="images/imgDefault.jpg" 
                 alt="New Product" 
                 style="height:280px; margin:auto; display:block;">
        </div>

        <!-- Right side: Product Info + Fields -->
        <div>
            <label style="font-size: 23px;">Product Name: </label>
            <input type="text" style="font-size: 23px;" name="name" required><br><br>

            <label style="font-size: 23px;">Short Description: </label>
            <input type="text" style="font-size: 23px; width:320px;" name="shortDesc" required><br><br>

            <label style="font-size: 23px;">Size: </label>
            <select style="font-size: 23px; width:190px;" name="size" required>
            <option value="">-- Select Size --</option>
            <option value="S">S</option>  
            <option value="M">M</option>  
            <option value="L">L</option>      
            <option value="None">No Size</option> </select>
            <br><br>

            <label style="font-size: 23px;">Price ($): </label>
            <input type="number" style="font-size: 23px; width:150px;" name="price" min="0.01" step="0.01" required><br><br>

            <label style="font-size: 23px;">Stock: </label>
            <input type="number" style="font-size: 23px; width:150px;" name="stock" min="0" required><br><br>

            <button type="submit" style="font-size: 23px;">Add Product</button>
        </div>
        
    </div>
</form>



</div> <?php include "footer.php"; ?>
</body>
</html>