<?php
session_start();
include 'connection.php';

function sanitize_input($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

function save_cart_to_cookie($cart) {
    setcookie('my_cart', json_encode($cart), time() + (86400 * 30), "/");
}

function load_cart_from_cookie() {
    if (isset($_COOKIE['my_cart'])) {
        return json_decode($_COOKIE['my_cart'], true);
    }
    return [];
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $product_id = isset($_POST['product_id']) ? intval($_POST['product_id']) : 0;
    $quantity = isset($_POST['quantity']) ? intval($_POST['quantity']) : 1;
    $size = isset($_POST['size']) ? sanitize_input($_POST['size']) : '';

    if ($product_id <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid product ID']);
        exit;
    }

    $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    $stock_query = "SELECT stock FROM products WHERE id = ?";
    $stmt = mysqli_prepare($conn, $stock_query);
    mysqli_stmt_bind_param($stmt, "i", $product_id);
    mysqli_stmt_execute($stmt);
    $stock_result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($stock_result) == 0) {
        mysqli_close($conn);
        echo json_encode(['status' => 'error', 'message' => 'Product not found']);
        exit;
    }

    $row = mysqli_fetch_assoc($stock_result);
    if ($row['stock'] < $quantity) {
        mysqli_close($conn);
        echo json_encode(['status' => 'error', 'message' => 'Insufficient stock']);
        exit;
    }

    mysqli_stmt_close($stmt);
    mysqli_close($conn);

    $cart = load_cart_from_cookie();

    $item_key = $product_id . "-" . $size;

    if (isset($cart[$item_key])) {
        $cart[$item_key]['quantity'] += $quantity;
    } else {
        $cart[$item_key] = [
            'product_id' => $product_id,
            'quantity' => $quantity,
            'size' => $size
        ];
    }

    save_cart_to_cookie($cart);

    echo json_encode(['status' => 'success', 'message' => 'Product added to cart']);

} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
}
?>