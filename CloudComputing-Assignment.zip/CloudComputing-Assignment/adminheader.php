<?php
session_start();

if (!isset($_SESSION['staff_logged_in']) || $_SESSION['staff_logged_in'] !== true) {
    header("Location: adminLogin.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Area</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f6f9;
            color: #333;
            line-height: 1.6;
        }

        header {
            background: linear-gradient(135deg, #2c3e50, #1a252f);
            color: white;
            padding: 1.2rem 0;
            text-align: center;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }

        header h1 {
            margin: 0;
            font-weight: 400;
            letter-spacing: 1px;
        }

        nav {
            padding: 0.7rem 0;
            background-color: #34495e;
            text-align: center;
            box-shadow: 0 2px 4px rgba(0, 0, 0, 0.1);
            position: sticky;
            top: 0;
            z-index: 100;
        }

        nav a {
            color: white;
            text-decoration: none;
            padding: 0.6rem 1.2rem;
            margin: 0 0.3rem;
            border-radius: 4px;
            transition: all 0.3s ease;
            display: inline-block;
            font-weight: 500;
        }

        nav a {
            margin: 0 10px;
        }

        nav a:hover {
            background-color: #3498db;
            transform: translateY(-2px);
        }

        .admin-content {
            padding: 25px;
            margin: 25px auto;
            max-width: 1200px;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
        }

        @media (max-width: 768px) {
            .admin-content {
                margin: 15px;
                padding: 15px;
            }
            
            nav a {
                padding: 0.5rem 0.8rem;
                margin: 0.2rem;
                display: inline-block;
            }
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 1rem 0;
        }

        table th, table td {
            padding: 12px 15px;
            text-align: left;
            border-bottom: 1px solid #e0e0e0;
        }

        table th {
            background-color: #f8f9fa;
            font-weight: 600;
        }

        table tr:hover {
            background-color: #f5f5f5;
        }
    </style>
</head>
<body>
    <header>
        <h1>Admin Panel</h1>
    </header>
    <nav>
        <a href="adminpage.php">Dashboard</a> |
        <a href="add_product.php">Add Product</a> |
        <a href="adminLogout.php">Logout</a>
    </nav>
    <div class="admin-content">