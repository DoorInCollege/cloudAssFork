-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 04, 2025 at 05:18 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `grad`
--

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `order_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `total_amount` decimal(10,2) NOT NULL,
  `customer_name` varchar(255) NOT NULL,
  `customer_email` varchar(255) NOT NULL,
  `shipping_address_street` varchar(255) NOT NULL,
  `shipping_address_city` varchar(100) NOT NULL,
  `shipping_address_state` varchar(50) NOT NULL,
  `shipping_address_postal_code` varchar(20) NOT NULL,
  `customer_phone` varchar(20) DEFAULT NULL,
  `payment_status` varchar(50) NOT NULL,
  `shipping_status` varchar(50) NOT NULL DEFAULT 'Pending',
  `delivery_fee` decimal(10,2) NOT NULL DEFAULT 0.00
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `order_item_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `size` varchar(50) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci ROW_FORMAT=DYNAMIC;

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `payment_method` varchar(100) NOT NULL,
  `transaction_id` varchar(255) DEFAULT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_status` varchar(50) NOT NULL,
  `payment_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `currency` varchar(10) DEFAULT 'USD',
  `payment_details` text DEFAULT NULL,
  `cc_last_digits` varchar(4) DEFAULT NULL,
  `tng_masked_number` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `shortDesc` varchar(50) NOT NULL,
  `description` varchar(200) NOT NULL,
  `image` varchar(100) NOT NULL DEFAULT 'imgDefault.jpg',
  `size` varchar(4) NOT NULL,
  `stock` int(11) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `name`, `shortDesc`, `description`, `image`, `size`, `stock`, `price`) VALUES
(1, 'Graduation Cap', 'Classic black graduation cap', 'A classic black graduation cap, perfect for your big day', 'gradcap.png', 'S', 40, 19.99),
(2, 'Graduation Cap', 'Classic black graduation cap', 'A classic black graduation cap, perfect for your big day', 'gradcap.png', 'M', 30, 24.99),
(3, 'Graduation Cap', 'Classic black graduation cap', 'A classic black graduation cap, perfect for your big day', 'gradcap.png', 'L', 30, 29.99),
(4, 'Graduation Gown', 'Traditional black graduation gown', 'A traditional black gown designed for elegance and comfort', 'gradgown.png', 'S', 30, 49.99),
(5, 'Graduation Gown', 'Traditional black graduation gown', 'A traditional black gown designed for elegance and comfort', 'gradgown.png', 'M', 40, 54.99),
(6, 'Graduation Gown', 'Traditional black graduation gown', 'A traditional black gown designed for elegance and comfort', 'gradgown.png', 'L', 30, 59.99),
(7, 'Graduation Set (Cap + Gown)', 'Complete graduation set', 'Everything you need to shine at graduation in one bundle', 'fullgrad.jpg', 'S', 30, 64.99),
(8, 'Graduation Set (Cap + Gown)', 'Complete graduation set', 'Everything you need to shine at graduation in one bundle', 'fullgrad.jpg', 'M', 35, 69.99),
(9, 'Graduation Set (Cap + Gown)', 'Complete graduation set', 'Everything you need to shine at graduation in one bundle', 'fullgrad.jpg', 'L', 35, 74.99),
(10, 'Flower Bouquet', 'A beautiful bouquet', 'A stunning bouquet to celebrate your achievements in style', 'gradbouquet.jpg', 'One ', 100, 29.99),
(11, 'Grad Mug', 'Ceramic mug with your name', 'A personalized ceramic mug to cherish your graduation memories (uses registered name)', 'gradmug.jpg', 'One ', 100, 14.99),
(12, 'Grad Hoodie', 'A cozy hoodie', 'A soft, cozy hoodie to keep you warm while celebrating your success (uses year enrolled of Graduate)', 'gradhood.jpg', 'M', 40, 24.99),
(13, 'Grad Hoodie', 'A cozy hoodie', 'A soft, cozy hoodie to keep you warm while celebrating your success (uses year enrolled of Graduate)', 'gradhood.jpg', 'L', 60, 29.99);

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `staff_id` varchar(6) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `staff`
--

INSERT INTO `staff` (`staff_id`, `username`, `password`) VALUES
('STF001', 'staff1', '123'),
('STF002', 'staff2', '123');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`order_item_id`),
  ADD KEY `order_id` (`order_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`),
  ADD KEY `order_id` (`order_id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`staff_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `order_item_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `order_items`
--
ALTER TABLE `order_items`
  ADD CONSTRAINT `order_items_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`),
  ADD CONSTRAINT `order_items_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`);

--
-- Constraints for table `payments`
--
ALTER TABLE `payments`
  ADD CONSTRAINT `payments_ibfk_1` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`),
  ADD CONSTRAINT `payments_ibfk_2` FOREIGN KEY (`order_id`) REFERENCES `orders` (`order_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
