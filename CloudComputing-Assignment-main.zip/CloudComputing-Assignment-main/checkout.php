<?php
session_start();
$_SESSION['test'] = 'hello';
include 'connection.php';
include 'header.php';

// Establish the database connection
$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Function to get product details
function getProductDetails($conn, $product_id) {
    $sql = "SELECT name, price FROM products WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $product_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    if ($row = mysqli_fetch_assoc($result)) {
        return $row;
    }
    return null;
}

// Get cart items from cookie
$cart = json_decode($_COOKIE['my_cart'] ?? '[]', true);

if (empty($cart)) {
    echo "<div class='container'><p>Your cart is empty. <a href='products.php'>Continue shopping</a>.</p></div>";
    include 'footer.php';
    exit();
}

$total_amount = 0;
$cart_items_details = [];
foreach ($cart as $item_key => $item_data) {
    $product_id = $item_data['product_id'];
    $quantity = $item_data['quantity'];
    $size = $item_data['size'];

    $product = getProductDetails($conn, $product_id);
    if ($product) {
        $cart_items_details[] = [
            'name' => $product['name'],
            'price' => $product['price'],
            'quantity' => $quantity,
            'size' => $size
        ];
        $total_amount += $product['price'] * $quantity;
    }
}

mysqli_close($conn);

// Initialize error array
$errors = [];

// Function to sanitize input
function sanitize_input($data) {
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return $data;
}

// Process form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Sanitize and validate Full Name
    $customer_name = sanitize_input($_POST['customer_name']);
    if (empty($customer_name)) {
        $errors['customer_name'] = "Full Name is required.";
    } elseif (!preg_match("/^[a-zA-Z\s]+$/", $customer_name)) {
        $errors['customer_name'] = "Full Name can only contain letters and spaces.";
    }

    // Sanitize and validate Email Address
    $customer_email = sanitize_input($_POST['customer_email']);
    if (empty($customer_email)) {
        $errors['customer_email'] = "Email Address is required.";
    } elseif (!filter_var($customer_email, FILTER_VALIDATE_EMAIL)) {
        $errors['customer_email'] = "Invalid Email Address format.";
    }

    // Sanitize and validate Street Address
    $shipping_address_street = sanitize_input($_POST['shipping_address_street']);
    if (empty($shipping_address_street)) {
        $errors['shipping_address_street'] = "Street Address is required.";
    }

    // Sanitize and validate City
    $shipping_address_city = sanitize_input($_POST['shipping_address_city']);
    if (empty($shipping_address_city)) {
        $errors['shipping_address_city'] = "City is required.";
    } elseif (!preg_match("/^[a-zA-Z\s]+$/", $shipping_address_city)) {
        $errors['shipping_address_city'] = "City can only contain letters and spaces.";
    }

    // Sanitize and validate State/Province
    $shipping_address_state = sanitize_input($_POST['shipping_address_state']);
    if (empty($shipping_address_state)) {
        $errors['shipping_address_state'] = "State/Province is required.";
    } elseif (!preg_match("/^[a-zA-Z\s]+$/", $shipping_address_state)) {
        $errors['shipping_address_state'] = "State/Province can only contain letters and spaces.";
    }

    // Sanitize and validate Postal Code
    $shipping_address_postal_code = sanitize_input($_POST['shipping_address_postal_code']);
    if (empty($shipping_address_postal_code)) {
        $errors['shipping_address_postal_code'] = "Postal Code is required.";
    } elseif (!preg_match("/^\d{5}$/", $shipping_address_postal_code)) {
        $errors['shipping_address_postal_code'] = "Invalid Postal Code format. Must be 5 digits.";
    }

    // Sanitize and validate Phone Number with length check
    $customer_phone = sanitize_input($_POST['customer_phone']);
    if (empty($customer_phone)) {
        $errors['customer_phone'] = "Phone Number is required.";
    } elseif (!preg_match("/^[0-9\s\-+]+$/", $customer_phone)) {
        $errors['customer_phone'] = "Invalid Phone Number format.";
    } elseif (strlen($customer_phone) < 7 || strlen($customer_phone) > 15) {
        $errors['customer_phone'] = "Phone Number must be between 7 and 15 digits long.";
    }

    // If there are no errors, proceed to payment
    if (empty($errors)) {
        // Redirect to payment.php
        $_SESSION['checkout_data'] = $_POST;
        header("Location: payment.php");
        exit();
    }
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Checkout</title>
    <link rel="stylesheet" href="css/checkout.css">
    <link rel="icon" href="images/logo.jpg" type="image/x-icon"/>
    <style>
        .error {
            color: red;
            font-size: 0.9em;
            margin-top: 5px;
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Checkout</h1>

    <div class="checkout-details">
        <h2>Order Summary</h2>
        <?php
        $grand_total = 0;
        foreach ($cart_items_details as $item) {
            $subtotal = $item['price'] * $item['quantity'];
            $grand_total += $subtotal;
            echo "<p>{$item['name']} ({$item['size']}) x {$item['quantity']} - RM" . number_format($subtotal, 2) . "</p>";
        }
        $delivery_fee = 10; // You might fetch this from a database or configuration
        $grand_total_with_delivery = $grand_total + $delivery_fee;
        echo "<p>Total Amount: RM" . number_format($grand_total, 2) . "</p>"; 
        echo "<p>Delivery Fee: RM" . number_format($delivery_fee, 2) . "</p>";
        echo "<p>Grand Total (incl. delivery): RM" . number_format($grand_total_with_delivery, 2) . "</p>";
        ?>
    </div>

    <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="post">
        <div class="form-group">
            <label for="customer_name">Full Name:</label>
            <input type="text" class="form-control" id="customer_name" name="customer_name" value="<?php echo isset($_POST['customer_name']) ? htmlspecialchars($_POST['customer_name']) : ''; ?>" required>
            <?php if (isset($errors['customer_name'])) echo '<div class="error">' . $errors['customer_name'] . '</div>'; ?>
        </div>
        <div class="form-group">
            <label for="customer_email">Email Address:</label>
            <input type="email" class="form-control" id="customer_email" name="customer_email" value="<?php echo isset($_POST['customer_email']) ? htmlspecialchars($_POST['customer_email']) : ''; ?>" required>
            <?php if (isset($errors['customer_email'])) echo '<div class="error">' . $errors['customer_email'] . '</div>'; ?>
        </div>
        <div class="form-group">
            <label for="shipping_address_street">Street Address:</label>
            <input type="text" class="form-control" id="shipping_address_street" name="shipping_address_street" value="<?php echo isset($_POST['shipping_address_street']) ? htmlspecialchars($_POST['shipping_address_street']) : ''; ?>" required>
            <?php if (isset($errors['shipping_address_street'])) echo '<div class="error">' . $errors['shipping_address_street'] . '</div>'; ?>
        </div>
        <div class="form-group">
            <label for="shipping_address_city">City:</label>
            <input type="text" class="form-control" id="shipping_address_city" name="shipping_address_city" value="<?php echo isset($_POST['shipping_address_city']) ? htmlspecialchars($_POST['shipping_address_city']) : ''; ?>" required>
            <?php if (isset($errors['shipping_address_city'])) echo '<div class="error">' . $errors['shipping_address_city'] . '</div>'; ?>
        </div>
        <div class="form-group">
            <label for="shipping_address_state">State/Province:</label>
            <input type="text" class="form-control" id="shipping_address_state" name="shipping_address_state" value="<?php echo isset($_POST['shipping_address_state']) ? htmlspecialchars($_POST['shipping_address_state']) : ''; ?>" required>
            <?php if (isset($errors['shipping_address_state'])) echo '<div class="error">' . $errors['shipping_address_state'] . '</div>'; ?>
        </div>
        <div class="form-group">
            <label for="shipping_address_postal_code">Postal Code:</label>
            <input type="text" class="form-control" id="shipping_address_postal_code" name="shipping_address_postal_code" value="<?php echo isset($_POST['shipping_address_postal_code']) ? htmlspecialchars($_POST['shipping_address_postal_code']) : ''; ?>" required>
            <?php if (isset($errors['shipping_address_postal_code'])) echo '<div class="error">' . $errors['shipping_address_postal_code'] . '</div>'; ?>
        </div>
        <div class="form-group">
            <label for="customer_phone">Phone Number:</label>
            <input type="text" class="form-control" id="customer_phone" name="customer_phone" value="<?php echo isset($_POST['customer_phone']) ? htmlspecialchars($_POST['customer_phone']) : ''; ?>" required>
            <?php if (isset($errors['customer_phone'])) echo '<div class="error">' . $errors['customer_phone'] . '</div>'; ?>
        </div>

        <input type="hidden" name="total_amount" value="<?php echo htmlspecialchars($grand_total); ?>">
        <input type="hidden" name="delivery_fee" value="<?php echo htmlspecialchars($delivery_fee); ?>">
        <button type="submit" class="btn btn-primary">Proceed to Payment</button>
    </form>
</div>


<?php include 'footer.php'; ?>
</body>
</html>