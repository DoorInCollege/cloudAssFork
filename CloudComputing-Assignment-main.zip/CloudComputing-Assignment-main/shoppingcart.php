<?php
session_start();
include 'connection.php';

$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

function load_cart_from_cookie() {
    if (isset($_COOKIE['my_cart'])) {
        return json_decode($_COOKIE['my_cart'], true);
    }
    return [];
}

function getProductDetails($conn, $product_id) {
    $sql = "SELECT name, image, price FROM products WHERE id = ?";
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "i", $product_id);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);
    if ($row = mysqli_fetch_assoc($result)) {
        return $row;
    }
    return null;
}

// Handle quantity update
if (isset($_POST['update_quantity']) && $_POST['update_quantity'] === 'true') {
    $item_key = $_POST['item_key'];
    $quantity = intval($_POST['quantity']);

    $cart = load_cart_from_cookie();

    if (isset($cart[$item_key])) {
        $cart[$item_key]['quantity'] = $quantity;

        $parts = explode('-', $item_key);
        $product_id = $parts[0];
        $product = getProductDetails($conn, $product_id);

        if ($product) {
            $new_subtotal = 'RM' . number_format($product['price'] * $quantity, 2);
            setcookie('my_cart', json_encode($cart), time() + (86400 * 30), "/");
            echo json_encode(['status' => 'success', 'new_subtotal' => $new_subtotal]);
            exit();
        } else {
            echo json_encode(['status' => 'error', 'message' => 'Product details not found.']);
            exit();
        }
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Item not found in cart.']);
        exit();
    }
}

// Load cart from cookie
$cart = load_cart_from_cookie();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" href="images/logo.jpg" type="image/x-icon"/>
</head>
<body>

    <?php include "header.php"; ?>

    <div class="container">
        <h1>Shopping Cart</h1>

        <div class="cart-container">
            <?php if (empty($cart)): ?>
                <div class="empty-cart">
                    <p>Your cart is empty.</p>
                    <a href="products.php">Continue shopping</a>
                </div>
            <?php else: ?>
                <?php
                $total = 0;
                foreach ($cart as $item_key => $item_data):
                    $parts = explode('-', $item_key);
                    $product_id = $parts[0];
                    $size = $parts[1];
                    $quantity = $item_data['quantity'];
                    $product = getProductDetails($conn, $product_id);
                    if ($product):
                        $subtotal = $product['price'] * $quantity;
                        $total += $subtotal;
                ?>
                    <div class="cart-item" data-item-key="<?php echo htmlspecialchars($item_key); ?>">
                        <img src="images/<?php echo htmlspecialchars($product['image']); ?>" alt="<?php echo htmlspecialchars($product['name']); ?>">
                        <div class="cart-item-details">
                            <h3><?php echo htmlspecialchars($product['name']); ?></h3>
                            <p>Size: <?php echo htmlspecialchars($size); ?></p>
                            <div class="quantity-control">
                                <label for="quantity_<?php echo htmlspecialchars($item_key); ?>">Quantity:</label>
                                <input type="number" id="quantity_<?php echo htmlspecialchars($item_key); ?>" name="quantity" value="<?php echo htmlspecialchars($quantity); ?>" min="1">
                                <button class="update-quantity-btn" data-item-key="<?php echo htmlspecialchars($item_key); ?>">Update</button>
                            </div>
                            <p class="price">RM<?php echo htmlspecialchars(number_format($product['price'], 2)); ?></p>
                            <p class="subtotal">Subtotal: <span class="subtotal-value">RM<?php echo htmlspecialchars(number_format($subtotal, 2)); ?></span></p>
                            <button class="remove-btn" onclick="removeItem('<?php echo htmlspecialchars($item_key); ?>')">Remove</button>
                        </div>
                    </div>
                <?php
                    endif;
                endforeach;
                mysqli_close($conn);
                ?>

                <div class="cart-summary">
                    <p>Total: <span class="cart-total">RM<?php echo htmlspecialchars(number_format($total, 2)); ?></span></p>
                    <a href="checkout.php" class="checkout-btn">Proceed to Checkout</a>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="toast-container"></div>

    <?php include "footer.php"; ?>

    <script src="cart.js"></script>
</body>
</html>