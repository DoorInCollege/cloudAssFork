<?php
session_start();

// Function to load cart from cookie
function load_cart_from_cookie() {
    if (isset($_COOKIE['my_cart'])) {
        return json_decode($_COOKIE['my_cart'], true);
    }
    return [];
}

// Function to save cart to cookie
function save_cart_to_cookie($cart) {
    setcookie('my_cart', json_encode($cart), time() + (86400 * 30), "/"); // Cookie expires in 30 days
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $item_key = isset($_POST['item_key']) ? $_POST['item_key'] : '';

    if (empty($item_key)) {
        echo json_encode(['status' => 'error', 'message' => 'Invalid item key']);
        exit;
    }

    $cart = load_cart_from_cookie();

    if (isset($cart[$item_key])) {
        unset($cart[$item_key]);
        save_cart_to_cookie($cart);
        echo json_encode(['status' => 'success', 'message' => 'Item removed from cart']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Item not found in cart']);
    }
} else {
    echo json_encode(['status' => 'error', 'message' => 'Invalid request']);
}
?>