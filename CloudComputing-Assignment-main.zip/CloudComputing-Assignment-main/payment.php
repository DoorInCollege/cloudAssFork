<?php
session_start();
include 'connection.php';
include 'header.php';

$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

function sanitize_input($data) {
    return htmlspecialchars(stripslashes(trim($data)));
}

// Check if checkout data exists in the session
if (isset($_SESSION['checkout_data'])) {
    $checkout_data = $_SESSION['checkout_data'];
    // Don't unset the checkout_data if there are errors - we need it for repopulating the form
    if (!isset($_SESSION['payment_errors'])) {
        unset($_SESSION['checkout_data']); // Only clear if no errors
    }

    $customer_name = sanitize_input($checkout_data['customer_name']);
    $customer_email = sanitize_input($checkout_data['customer_email']);
    $shipping_address_street = sanitize_input($checkout_data['shipping_address_street']);
    $shipping_address_city = sanitize_input($checkout_data['shipping_address_city']);
    $shipping_address_state = sanitize_input($checkout_data['shipping_address_state']);
    $shipping_address_postal_code = sanitize_input($checkout_data['shipping_address_postal_code']);
    $customer_phone = sanitize_input($checkout_data['customer_phone']);
    $total_amount = floatval($checkout_data['total_amount']);
    $delivery_fee = floatval($checkout_data['delivery_fee']);

    
    // Now you can safely proceed with displaying payment information
    ?>
    <!DOCTYPE html>
    <html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Payment</title>
        <link rel="icon" href="images/logo.jpg" type="image/x-icon"/>
        <link rel="stylesheet" href="css/payment.css">
        <style>
            .error-message {
                color: #d9534f;
                font-size: 14px;
                margin-top: 5px;
                display: block;
            }
            .payment-details {
                padding: 15px;
                border: 1px solid #ddd;
                border-radius: 5px;
                margin-top: 10px;
                margin-bottom: 15px;
                background-color: #f9f9f9;
            }
            .form-group {
                margin-bottom: 15px;
            }
            .form-group label {
                display: block;
                margin-bottom: 5px;
                font-weight: bold;
            }
            .form-control {
                width: 100%;
                padding: 8px;
                border: 1px solid #ccc;
                border-radius: 4px;
            }
            .system-error {
                padding: 10px;
                background-color: #f8d7da;
                color: #721c24;
                border: 1px solid #f5c6cb;
                border-radius: 4px;
                margin-bottom: 20px;
            }
        </style>
    </head>
    <body>
    <div class="container">
        <h1>Payment</h1>

        <?php if (isset($_SESSION['payment_errors']) && !empty($_SESSION['payment_errors'])): ?>
            <?php if (isset($_SESSION['payment_errors']['system'])): ?>
                <div class="system-error">
                    <?php echo $_SESSION['payment_errors']['system']; ?>
                </div>
            <?php endif; ?>
        <?php endif; ?>

        <h2>Order Summary</h2>
        <p>Customer Name: <?php echo htmlspecialchars($customer_name); ?></p>
        <p>Subtotal: RM <?php echo htmlspecialchars(number_format($total_amount - $delivery_fee, 2)); ?></p>
        <p>Delivery Fee: RM <?php echo htmlspecialchars(number_format($delivery_fee, 2)); ?></p>
        <p>Total Amount: RM <?php echo htmlspecialchars(number_format($total_amount, 2)); ?></p>

        <h2>Choose Payment Method</h2>
        <form action="process_order.php" method="post" id="paymentForm">
            <input type="hidden" name="customer_name" value="<?php echo htmlspecialchars($customer_name); ?>">
            <input type="hidden" name="customer_email" value="<?php echo htmlspecialchars($customer_email); ?>">
            <input type="hidden" name="shipping_address_street" value="<?php echo htmlspecialchars($shipping_address_street); ?>">
            <input type="hidden" name="shipping_address_city" value="<?php echo htmlspecialchars($shipping_address_city); ?>">
            <input type="hidden" name="shipping_address_state" value="<?php echo htmlspecialchars($shipping_address_state); ?>">
            <input type="hidden" name="shipping_address_postal_code" value="<?php echo htmlspecialchars($shipping_address_postal_code); ?>">
            <input type="hidden" name="customer_phone" value="<?php echo htmlspecialchars($customer_phone); ?>">
            <input type="hidden" name="total_amount" value="<?php echo htmlspecialchars($total_amount); ?>">
            <input type="hidden" name="delivery_fee" value="<?php echo htmlspecialchars($delivery_fee); ?>">
            
            <div>
                <input type="radio" name="payment_method" value="cash_on_delivery" required data-fields="" <?php echo isset($_POST['payment_method']) && $_POST['payment_method'] == 'cash_on_delivery' ? 'checked' : ''; ?>> Cash On Delivery
                <div id="cod_details" class="payment-details">
                    <p>You will pay in cash upon delivery.</p>
                </div>
                <?php if (isset($_SESSION['payment_errors']['payment_method'])): ?>
                    <span class="error-message"><?php echo $_SESSION['payment_errors']['payment_method']; ?></span>
                <?php endif; ?>
            </div>

            <div>
                <input type="radio" name="payment_method" value="credit_card" required data-fields="cc" <?php echo isset($_POST['payment_method']) && $_POST['payment_method'] == 'credit_card' ? 'checked' : ''; ?>> Credit Card
                <div id="credit_card_details" class="payment-details">
                    <div class="form-group">
                        <label for="cc_number">Card Number:</label>
                        <input type="text" class="form-control" id="cc_number" name="cc_number" placeholder="XXXX-XXXX-XXXX-XXXX" maxlength="19" pattern="\d{13,19}">
                        <?php if (isset($_SESSION['payment_errors']['cc_number'])): ?>
                            <span class="error-message"><?php echo $_SESSION['payment_errors']['cc_number']; ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="cc_expiry">Expiry Date:</label>
                        <input type="text" class="form-control" id="cc_expiry" name="cc_expiry" placeholder="MM/YY" maxlength="5" pattern="(0[1-9]|1[0-2])\/\d{2}">
                        <?php if (isset($_SESSION['payment_errors']['cc_expiry'])): ?>
                            <span class="error-message"><?php echo $_SESSION['payment_errors']['cc_expiry']; ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="cc_cvv">CVV:</label>
                        <input type="text" class="form-control" id="cc_cvv" name="cc_cvv" placeholder="123" maxlength="4" pattern="\d{3,4}">
                        <?php if (isset($_SESSION['payment_errors']['cc_cvv'])): ?>
                            <span class="error-message"><?php echo $_SESSION['payment_errors']['cc_cvv']; ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div>
                <input type="radio" name="payment_method" value="debit_card" required data-fields="dc" <?php echo isset($_POST['payment_method']) && $_POST['payment_method'] == 'debit_card' ? 'checked' : ''; ?>> Debit Card
                <div id="debit_card_details" class="payment-details">
                    <div class="form-group">
                        <label for="dc_number">Card Number:</label>
                        <input type="text" class="form-control" id="dc_number" name="dc_number" placeholder="XXXX-XXXX-XXXX-XXXX" maxlength="19" pattern="\d{13,19}">
                        <?php if (isset($_SESSION['payment_errors']['dc_number'])): ?>
                            <span class="error-message"><?php echo $_SESSION['payment_errors']['dc_number']; ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="dc_expiry">Expiry Date:</label>
                        <input type="text" class="form-control" id="dc_expiry" name="dc_expiry" placeholder="MM/YY" maxlength="5" pattern="(0[1-9]|1[0-2])\/\d{2}">
                        <?php if (isset($_SESSION['payment_errors']['dc_expiry'])): ?>
                            <span class="error-message"><?php echo $_SESSION['payment_errors']['dc_expiry']; ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="dc_cvv">CVV:</label>
                        <input type="text" class="form-control" id="dc_cvv" name="dc_cvv" placeholder="123" maxlength="4" pattern="\d{3,4}">
                        <?php if (isset($_SESSION['payment_errors']['dc_cvv'])): ?>
                            <span class="error-message"><?php echo $_SESSION['payment_errors']['dc_cvv']; ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <div>
                <input type="radio" name="payment_method" value="tng" required data-fields="tng" <?php echo isset($_POST['payment_method']) && $_POST['payment_method'] == 'tng' ? 'checked' : ''; ?>> Touch 'n Go (TNG)
                <div id="tng_details" class="payment-details">
                    <div class="form-group">
                        <label for="tng_number">TNG Wallet Number:</label>
                        <input type="text" class="form-control" id="tng_number" name="tng_number" placeholder="01XXXXXXXXX" maxlength="11" pattern="01\d{8,9}">
                        <?php if (isset($_SESSION['payment_errors']['tng_number'])): ?>
                            <span class="error-message"><?php echo $_SESSION['payment_errors']['tng_number']; ?></span>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <button type="submit" class="btn btn-primary">Complete Order</button>
        </form>
    </div>
    <script>
        const paymentRadios = document.querySelectorAll('input[name="payment_method"]');
        const paymentDetailsDivs = document.querySelectorAll('.payment-details');

        paymentDetailsDivs.forEach(div => {
            div.style.display = 'none'; // hide all detail sections
        });

        // Check if any radio is already checked (could be from validation error)
        const checkedRadio = document.querySelector('input[name="payment_method"]:checked');
        if (checkedRadio) {
            const selectedMethod = checkedRadio.value;
            const detailsDivId = selectedMethod + '_details';
            const detailsDiv = document.getElementById(detailsDivId);
            if (detailsDiv) {
                detailsDiv.style.display = 'block';
            }
            
            const selectedFields = checkedRadio.getAttribute('data-fields');
            enableRequiredFields(selectedFields);
        }

        paymentRadios.forEach(radio => {
            radio.addEventListener('change', function() {
                paymentDetailsDivs.forEach(div => {
                    div.style.display = 'none'; // Hide all
                });
                const selectedMethod = this.value;
                const detailsDivId = selectedMethod + '_details';
                const detailsDiv = document.getElementById(detailsDivId);
                if (detailsDiv) {
                    detailsDiv.style.display = 'block'; // Show the selected one
                }

                const selectedFields = this.getAttribute('data-fields');
                enableRequiredFields(selectedFields);
            });
        });
        
        function enableRequiredFields(selectedFields) {
            const allInputs = document.querySelectorAll('#paymentForm input[type="text"]');
            allInputs.forEach(input => {
                input.disabled = true;
                input.required = false;
            });

            if (selectedFields === 'cc') {
                document.getElementById('cc_number').disabled = false;
                document.getElementById('cc_number').required = true;
                document.getElementById('cc_expiry').disabled = false;
                document.getElementById('cc_expiry').required = true;
                document.getElementById('cc_cvv').disabled = false;
                document.getElementById('cc_cvv').required = true;
            } else if (selectedFields === 'dc') {
                document.getElementById('dc_number').disabled = false;
                document.getElementById('dc_number').required = true;
                document.getElementById('dc_expiry').disabled = false;
                document.getElementById('dc_expiry').required = true;
                document.getElementById('dc_cvv').disabled = false;
                document.getElementById('dc_cvv').required = true;
            } else if (selectedFields === 'tng') {
                document.getElementById('tng_number').disabled = false;
                document.getElementById('tng_number').required = true;
            }
        }
    </script>
    <?php 
    // Clear payment errors after displaying them
    if (isset($_SESSION['payment_errors'])) {
        unset($_SESSION['payment_errors']);
    }
    include 'footer.php'; 
    ?>
    </body>
    </html>
    <?php
} else {
    echo "<div class='container'><h1>Error</h1><p>Invalid access. Please return to the checkout page.</p></div>";
    include 'footer.php';
    exit();
}
mysqli_close($conn);
?>