<?php 

include "adminheader.php"; 
include "connection.php";

$con = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if ($con->connect_error) {
    die("Connection failed: " . $con->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Get updated values from the form
    $product_id = $_POST['id'];
    $name = $_POST['name'];
    $shortDesc = $_POST['shortDesc'];
    $size = $_POST['size'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];

    // Prepare the SQL query
    $sql = "UPDATE products SET name = ?, shortDesc = ?, size = ?, price = ?, stock = ? WHERE id = ?"; 

    // Bind the parameters and execute
    $stmt = $con->prepare($sql);
    $stmt->bind_param("sssdis", $name, $shortDesc, $size, $price, $stock, $product_id);
    
    if ($stmt->execute()) {
        // If update is successful
        echo "<div class='notification success'>Product updated successfully!</div>";
        echo "<p><a href='adminpage.php'>Go back to Dashboard</a></p>";
        exit();  // Stop processing
    } else {
        // If update fails
        echo "<div class='notification error'>Failed to update product.</div>";
        echo "<p><a href='adminpage.php'>Go back to Dashboard</a></p>";
        exit();  // Stop processing
    }

    $stmt->close();
}
?>


<h2 >Edit Product</h2>

<!-- h3>Edit Product</h3-->


<style>
    .admin-content {
            max-width: 1100px;}
</style>




<?php
if (isset($_GET['id'])) {
    $product_id = $_GET['id'];

    $sql = "SELECT * FROM products WHERE id = ?"; 
    $stmt = $con->prepare($sql);
    $stmt->bind_param("i", $product_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc(); 
}  else {
    // If 'id' is not passed, display error
    echo "<div style='color: red; font-size: 18px;'>Error: Product ID is missing.</div>";
    echo "<p><a href='adminpage.php'>Go back to Dashboard</a></p>";
    exit();  // Stop processing
}
?>

<?php


echo "<form action='edit_product.php' method='POST'>";
echo "<input type='hidden' name='id' value='" . $row['id'] . "'>";
echo "<div style='display: flex; justify-content: center; margin-bottom: 20px; gap: 30px';>";

// Left side: Image
echo "<div>";
echo "<img src='images/" . htmlspecialchars($row['image']) . "' alt='" . htmlspecialchars($row['name']) . "' style='height:280px; margin:auto; display:block;'>";
echo "</div>";


// Right side: Product Info + Fields
echo "<div>";
echo "<label style='font-size: 23px;'>Product Name: </label>"; 
echo "<input type='text' style='font-size: 23px;' name='name' value='" . htmlspecialchars($row['name']) . "'><br><br>";

echo "<label style='font-size: 23px;'>Short Description: </label> <input type='text' style='font-size: 23px; width:320px;' name='shortDesc' value='" . htmlspecialchars($row['shortDesc']) . "'><br><br>";

echo "<label style='font-size: 23px;'>Size: </label>";  
echo "<input type='text' style='font-size: 23px;  width:150px;' name='size' value='" . htmlspecialchars($row['size']) . "' disabled><br><br>";
echo "<input type='hidden' name='size' value='" . htmlspecialchars($row['size']) . "'>";

echo "<label style='font-size: 23px;'>Price ($): </label>";
echo "<input type='number' style='font-size: 23px; width:150px;' name='price' min='0.01' step='0.01' value='" . htmlspecialchars($row['price']) . "'  required><br><br>";

echo "<label style='font-size: 23px;'>Stock: </label>";
echo "<input type='number' style='font-size: 23px; width:150px;' name='stock'  value='" . htmlspecialchars($row['stock']) . "' min='0' required><br><br>";

echo "<button type='submit' style='font-size: 23px;'>Update Item</button>";
echo "</div>";


echo "</div>";
echo "</form>";
?>


</div> </div> <?php include "footer.php"; ?>
</body>

</html>


