<?php

include 'connection.php';

$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

$sql = "SELECT DISTINCT name, image, shortDesc FROM products";
$result = mysqli_query($conn, $sql);

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Products</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="icon" href="images/logo.jpg" type="image/x-icon"/>
</head>
<body>

    <?php include "header.php" ?>

    <div class="container">
        <h1>Our Products</h1>

        <div class="products-container">
            <?php
            // Check if there are any products
            if (mysqli_num_rows($result) > 0) {
                // Loop through each unique product
                while($row = mysqli_fetch_assoc($result)) {
                    // Fetch all sizes and prices for the current product
                    $productName = mysqli_real_escape_string($conn, $row['name']);
                    $sizesQuery = "SELECT DISTINCT size, price, id FROM products WHERE name = '$productName' AND stock > 0";
                    $sizesResult = mysqli_query($conn, $sizesQuery);
                    $availableSizes = [];
                    $sizePrices = [];
                    $productIdsBySize = [];
                    while ($sizeRow = mysqli_fetch_assoc($sizesResult)) {
                        $size = trim($sizeRow['size']);
                        if (!empty($size)) {
                            $availableSizes[] = $size;
                            $sizePrices[$size] = $sizeRow['price']; // Store price for each size
                            $productIdsBySize[$size] = $sizeRow['id']; // Store product ID for each size
                        }
                    }
                    $uniqueSizes = array_unique($availableSizes);
                    sort($uniqueSizes); // Sort sizes for better presentation

                    // Find the lowest price to display initially
                    $lowestPrice = !empty($sizePrices) ? min($sizePrices) : 0;
                    ?>
                    <div class="product">
                        <img src="images/<?php echo htmlspecialchars($row['image']); ?>" alt="<?php echo htmlspecialchars($row['name']); ?>">
                        <h2><?php echo htmlspecialchars($row['name']); ?></h2>
                        <p class="price">RM<span id="price_<?php echo htmlspecialchars(str_replace(' ', '_', $row['name'])); ?>"><?php echo htmlspecialchars($lowestPrice); ?></span></p>  <?php if (!empty($uniqueSizes)): ?>
                            <label for="size_<?php echo htmlspecialchars(str_replace(' ', '_', $row['name'])); ?>">Size:</label>
                            <select id="size_<?php echo htmlspecialchars(str_replace(' ', '_', $row['name'])); ?>" name="size_<?php echo htmlspecialchars(str_replace(' ', '_', $row['name'])); ?>" onchange="updatePrice('<?php echo htmlspecialchars(str_replace(' ', '_', $row['name'])); ?>')">
                                <option value="">Select Size</option>
                                <?php foreach ($uniqueSizes as $size): ?>
                                    <option value="<?php echo htmlspecialchars($size); ?>" data-price="<?php echo htmlspecialchars($sizePrices[$size]); ?>" data-product-id="<?php echo htmlspecialchars($productIdsBySize[$size]); ?>"><?php echo htmlspecialchars($size); ?></option>
                                <?php endforeach; ?>
                            </select>
                            <button onclick="handleAddToCart('<?php echo htmlspecialchars(str_replace(' ', '_', $row['name'])); ?>')">Add to Cart</button>
                        <?php else: ?>
                            <p>Size: One Size</p>
                            <button onclick="showToast('<?php echo htmlspecialchars($row['name']); ?> added to cart');">Add to Cart</button>
                        <?php endif; ?>
                    </div>
                    <?php
                }
            } else {
                echo "<div class='empty-products'>No products found</div>";
            }
            ?>
        </div>
    </div>

    <?php mysqli_close($conn); ?>

    <?php include "footer.php" ?>

    <script src="cart.js"></script>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const productNames = <?php echo json_encode(array_map(function($p){ return str_replace(' ', '_', $p['name']); }, $products)); ?>;
            productNames.forEach(updatePriceOnLoad);

            const addToCartButtons = document.querySelectorAll('.add-to-cart-btn');
            addToCartButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const productName = this.getAttribute('data-product-name');
                    handleAddToCart(productName);
                });
            });
        });

        // Small helper to call updatePrice from cart.js on load
        function updatePriceOnLoad(productName) {
            if (typeof updatePrice === 'function') {
                updatePrice(productName);
            }
        }
    </script>
</body>
</html>