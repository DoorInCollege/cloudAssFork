<?php
session_start();
include 'connection.php';
include 'header.php';

$conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

if (isset($_GET['order_id']) && is_numeric($_GET['order_id']) && isset($_GET['payment_info']) && isset($_GET['delivery_fee'])) {
    $order_id = intval($_GET['order_id']);
    $payment_info = urldecode($_GET['payment_info']);
    $delivery_fee = floatval(urldecode($_GET['delivery_fee']));

    $conn = mysqli_connect(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    if (!$conn) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Fetch order details
    $order_query = "SELECT * FROM orders WHERE order_id = ?";
    $order_stmt = mysqli_prepare($conn, $order_query);
    mysqli_stmt_bind_param($order_stmt, "i", $order_id);
    mysqli_stmt_execute($order_stmt);
    $order_result = mysqli_stmt_get_result($order_stmt);
    $order = mysqli_fetch_assoc($order_result);

    // Fetch order items
    $items_query = "SELECT oi.*, p.name FROM order_items oi JOIN products p ON oi.product_id = p.id WHERE oi.order_id = ?";
    $items_stmt = mysqli_prepare($conn, $items_query);
    mysqli_stmt_bind_param($items_stmt, "i", $order_id);
    mysqli_stmt_execute($items_stmt);
    $items_result = mysqli_stmt_get_result($items_stmt);
    $order_items = mysqli_fetch_all($items_result, MYSQLI_ASSOC);

    mysqli_close($conn);

} else {
    die("Invalid order ID or payment/delivery information");
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Order Confirmation</title>
    <link rel="icon" href="images/logo.jpg" type="image/x-icon"/>
    <link rel="stylesheet" href="css/orderconfirmation.css">
</head>
<body class="order-confirmation-page">
<div class="oc-container">
    <h1 class="oc-title">Order Confirmation</h1>

    <?php if ($order): ?>
        <p class="oc-thank-you">Thank you for your order, <?php echo htmlspecialchars($order['customer_name']); ?>!</p>
        <p class="oc-order-id">Your order ID is: <?php echo htmlspecialchars($order['order_id']); ?></p>

        <h2 class="oc-subtitle">Shipping Information</h2>
        <div class="oc-shipping-info">
            <p>Address: <?php echo htmlspecialchars($order['shipping_address_street']); ?>, <?php echo htmlspecialchars($order['shipping_address_city']); ?>, <?php echo htmlspecialchars($order['shipping_address_state']); ?>, <?php echo htmlspecialchars($order['shipping_address_postal_code']); ?></p>
            <?php if (!empty($order['customer_phone'])): ?>
                <p>Phone Number: <?php echo htmlspecialchars($order['customer_phone']); ?></p>
            <?php endif; ?>
        </div>

        <h2 class="oc-subtitle">Order Details</h2>
        <div class="oc-order-details">
            <p><span>Subtotal:</span> <span>RM <?php echo htmlspecialchars(number_format($order['total_amount'] - $order['delivery_fee'], 2)); ?></span></p>
            <p><span>Delivery Fee:</span> <span>RM <?php echo htmlspecialchars(number_format($delivery_fee, 2)); ?></span></p>
            <p class="oc-total"><span>Total Amount:</span> <span>RM <?php echo htmlspecialchars(number_format($order['total_amount'], 2)); ?></span></p>
        </div>
        
        <div class="oc-payment-info">
            <p><?php echo htmlspecialchars($payment_info); ?></p>
        </div>
        
        <h3 class="oc-section-title">Items Ordered:</h3>
        <?php if (!empty($order_items)): ?>
            <ul class="oc-items">
                <?php foreach ($order_items as $item): ?>
                    <li class="oc-item"><?php echo htmlspecialchars($item['name']); ?> (Size: <?php echo htmlspecialchars($item['size']); ?>) - Quantity: <?php echo htmlspecialchars($item['quantity']); ?> - Price: RM <?php echo htmlspecialchars(number_format($item['price'], 2)); ?></li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <p class="oc-error">No items found in this order.</p>
        <?php endif; ?>

    <?php else: ?>
        <div class="oc-error">
            <p>Error: Order not found.</p>
        </div>
    <?php endif; ?>

    <p><a href="products.php" class="oc-continue-btn">Continue Shopping</a></p>
</div>

<?php include 'footer.php'; ?>  
</body>
</html>