<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Gradshop</title>
    <link rel="icon" href="images/logo.jpg" type="image/x-icon"/>
    <style>
        :root {
            --primary-color: #4a6fa5;
            --secondary-color: #2c3e50;
            --accent-color: #f39c12;
            --text-color: #333;
            --light-text: #6c757d;
            --light-bg: #f8f9fa;
            --white: #ffffff;
            --box-shadow: 0 10px 30px rgba(0, 0, 0, 0.07);
            --transition: all 0.3s ease;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background-color: var(--light-bg);
            color: var(--text-color);
            line-height: 1.6;
        }

        #about-container {
            max-width: 1200px;
            margin: 100px auto;
            padding: 70px;
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 70px;
            border-radius: 20px;
            background-color: var(--white);
            box-shadow: var(--box-shadow);
            transition: var(--transition);
            position: relative;
            overflow: hidden;
        }

        #about-container::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            width: 8px;
            height: 100%;
            background: linear-gradient(to bottom, var(--primary-color), var(--accent-color));
        }

        #about-container:hover {
            box-shadow: 0 15px 40px rgba(0, 0, 0, 0.12);
            transform: translateY(-5px);
        }

        #about-text {
            display: flex;
            flex-direction: column;
            justify-content: center;
        }

        h2 {
            color: var(--secondary-color);
            font-size: 3rem;
            margin-bottom: 30px;
            line-height: 1.2;
            position: relative;
            padding-bottom: 15px;
        }

        h2::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 80px;
            height: 4px;
            background: var(--accent-color);
            border-radius: 2px;
        }

        p {
            margin-bottom: 22px;
            font-size: 1.2rem;
            line-height: 1.9;
            color: var(--text-color);
        }

        p:last-child {
            font-weight: 500;
        }

        strong {
            color: var(--primary-color);
            position: relative;
            z-index: 1;
        }

        strong::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 30%;
            background-color: rgba(243, 156, 18, 0.3);
            z-index: -1;
            border-radius: 2px;
        }

        a {
            color: var(--primary-color);
            text-decoration: none;
            font-weight: 500;
            position: relative;
            transition: var(--transition);
        }

        a::after {
            content: '';
            position: absolute;
            bottom: -2px;
            left: 0;
            width: 0;
            height: 2px;
            background-color: var(--primary-color);
            transition: var(--transition);
        }

        a:hover {
            color: var(--primary-color);
        }

        a:hover::after {
            width: 100%;
            background-color: var(--primary-color);
        }

        .about-image {
            width: 100%;
            height: 100%;
            border-radius: 15px;
            box-shadow: 0 10px 25px rgba(0, 0, 0, 0.1);
            object-fit: cover;
            transition: var(--transition);
            filter: saturate(1.05);
        }

        .about-image:hover {
            transform: scale(1.02);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.15);
        }

        @media (max-width: 1100px) {
            #about-container {
                padding: 60px;
                gap: 50px;
                margin: 80px auto;
            }

            h2 {
                font-size: 2.5rem;
            }
        }

        @media (max-width: 992px) {
            #about-container {
                grid-template-columns: 1fr;
                text-align: left;
                padding: 50px;
                gap: 50px;
            }

            h2::after {
                left: 0;
                transform: none;
            }

            .about-image {
                max-width: 100%;
                margin: 0 auto;
                max-height: 500px;
            }
        }

        @media (max-width: 768px) {
            #about-container {
                padding: 40px 30px;
                margin: 60px 20px;
            }

            h2 {
                font-size: 2.2rem;
                margin-bottom: 20px;
            }

            p {
                font-size: 1.1rem;
                line-height: 1.8;
            }

            nav ul li {
                margin: 0 15px;
            }
        }

        @media (max-width: 576px) {
            #about-container {
                padding: 30px 25px;
                margin: 40px 15px;
            }

            h2 {
                font-size: 2rem;
            }

            p {
                font-size: 1rem;
            }

            nav ul li {
                margin: 0 10px;
            }
        }

        .footer-section {
            color: var(--white);
        }

        .footer-section h4 {
            font-size: 1.2rem;
            margin-bottom: 0.5em;
            color: var(--white);
        }

        .footer-section p {
            font-size: 0.9rem;
            line-height: 1.5;
            color: var(--white);
            margin-bottom: 0.3em;
        }

        .footer-section a {
            font-size: 0.9rem;
            color: var(--primary-color);
            text-decoration: underline;
        }

        .footer-section a:hover {
            color: var(--primary-color);
        }
    </style>
</head>
<body>
    <?php include "header.php" ?>
    <div id="about-container">
        <div id="about-text">
            <h2>Our Story</h2>
            <p>Gradshop started in 2019 in the vibrant town of Tanjung Bungah, Penang, with one simple mission — to make graduation unforgettable.</p>
            <p>We know what it feels like to cross that stage — the pride, the relief, the joy. That's why we create keepsakes that don't just look good, but <strong>mean</strong> something. Whether it's a custom stole, a framed diploma, or a thoughtful gift, each piece celebrates your journey and the people who helped you get there.</p>
            <p>We're not just a shop. We're your biggest cheerleaders, honoring milestones with heart.</p>
        </div>
        <img src="images/aboutus.jpg" alt="Graduation Celebration" class="about-image">
    </div>
    <?php include "footer.php" ?>
</body>
</html>