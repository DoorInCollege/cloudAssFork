# CloudComputing-Assignment
Y2S3 
